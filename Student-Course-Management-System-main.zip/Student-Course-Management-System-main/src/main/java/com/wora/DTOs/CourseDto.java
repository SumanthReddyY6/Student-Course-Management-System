package com.wora.DTOs;

public record CourseDto(Long id, String title) {
}
