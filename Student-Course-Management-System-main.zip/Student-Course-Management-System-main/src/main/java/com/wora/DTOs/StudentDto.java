package com.wora.DTOs;

public record StudentDto(Long id, String name, String email) {
}
