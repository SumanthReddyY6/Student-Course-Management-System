package com.wora.DTOs;

public record StudentsCourseDto(Long studentId, Long courseId) {
}
